

% set model parameters
alpha = .35;   %capital share in GDP .3
beta  = .96;  %discount factor .995
delta = .05; %depreciation rate 100% for exact solution to hold
lbar  = 1;     %labor per worker  1
gamma = 2;  %utility curvature
sigz = 0.0130058759370760;   %standard deviation for shocks .02
rhoz  = .95^4;    %autocorrelation of z series .9
zbar  = 0;
Zbar  = zbar;
rbar = (1 / beta) - 1 + delta;
NN = rho;
eps = .0000001;

% Create a vector of parameters that will be passed
param = [alpha, beta, delta, gamma]

% set starting state in terms of percent deviations from SS
Kstart = -.1;
zstart = 0;

% set program parameters
nmc = 1; %number of monte carlos
T = 1000; %sample size

%Solve for SS
af = @(x) Mod1ss(x,param);
guess = .03;
options = optimset('Display','iter','MaxFunEvals',100000000,...
          'MaxIter', 200000,'Algorithm','levenberg-marquardt',...
          'TolX',1.0e-8,'TolFun',1.0e-8);
Xbar = fsolve(af,guess,options);
guess = real(Xbar);
Xbar = fsolve(af,guess,options);
Kbar = Xbar;

temp = Mod1defs(Xbar, Zbar, Xbar, param);

Ybar = temp(1);
wbar = temp(2);
rbar = temp(3);
cbar = temp(4);


% read in SS values of input vector
in = [Kbar; Kbar; Kbar; zbar; zbar];

% check SS solution by passing in to dynamic eqations and confirm =0
zz = Mod1dyn(in,param);

if abs(zz)>1e-8;
    zz
	disp('SS must be off because Euler Error is not within given tolerance')
end;

% get PP & QQ matrices for log-linearization about the steady state

nx=1; %number of endogenous state variables (x's)
ny=0; %number of jump variables (y's)
nz=1; %number of exogenous state variables (z's)
incr= 1e-6; % epsilon for computing numerical derivatives

% linearizarion value of K
K0 = Kbar*10;

% read in SS values of input vector
in = [K0; K0; K0; zbar; zbar];

% Find coefficients about SS
[AA, BB, CC, DD, FF, GG, HH, JJ, KK, LL, MM, WW, TT] = ...
    LinApp_Deriv(@Mod1dyn,param,in,nx,ny,nz,0);
[PP, QQ, UU, RR, SS, VV] = ...
    LinApp_Solve(AA,BB,CC,DD,FF,GG,HH,JJ,KK,LL,MM,WW,TT,NN,0,0)

% read in plus values of input vector
inp = [K0+eps; K0+eps; K0+eps; zbar; zbar];

% Find coefficients
[AAp, BBp, CCp, DDp, FFp, GGp, HHp, JJp, KKp, LLp, MMp, WWp, TTp] = ...
    LinApp_Deriv(@Mod1dyn,param,inp,nx,ny,nz,0);
[PPp, QQp, UUp, RRp, SSp, VVp] = ...
    LinApp_Solve(AAp,BBp,CCp,DDp,FFp,GGp,HHp,JJp,KKp,LLp,MMp,WWp,TTp,...
    NN,0,0)

% read in minus SS values of input vector
inm = [K0-eps; K0-eps; K0-eps; zbar; zbar];

% Find coefficients about SS
[AAm, BBm, CCm, DDm, FFm, GGm, HHm, JJm, KKm, LLm, MMm, WWm, TTm] = ...
    LinApp_Deriv(@Mod1dyn,param,inm,nx,ny,nz,0);
[PPm, QQm, UUm, RRm, SSm, VVm] = ...
    LinApp_Solve(AAm,BBm,CCm,DDm,FFm,GGm,HHm,JJm,KKm,LLm,MMm,WWm,TTm,...
    NN,0,0)

PPapprox = (UUp-UUm)/(2*eps) + 1